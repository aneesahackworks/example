# Project Title

*Read this in other languages: [English](README.md), [한국어](README.ko.md), [português](README.pt_br.md).*

One or two paragraphs of project description goes here. Talk about the scope of the problem that you are addressing and include any relevant NGO definitions of existing goals or initiatives. Describe the impact of the problem on human lives and the wellbeing of communities.

Then explain the anticipated or proven impact of your solution, and explaining in particular the novel or innovative advantage this has over existing solutions that make it attractive to developers and users (such as potential customers).

[Project website](https://call-for-code.github.io/project-sample/)

